// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.a;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.b.k;
import android.util.AttributeSet;

public class c extends android.view.ViewGroup.MarginLayoutParams
{

    public int a;

    public c(int i)
    {
        this(-2, -1, i);
    }

    public c(int i, int j, int l)
    {
        super(i, j);
        a = -1;
        a = l;
    }

    public c(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        a = -1;
        context = context.obtainStyledAttributes(attributeset, k.ActionBarLayout);
        a = context.getInt(0, -1);
        context.recycle();
    }
}
