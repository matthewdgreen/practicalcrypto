// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.a;

import android.content.Context;
import android.view.View;

public abstract class a
{

    public a()
    {
    }

    public abstract int a();

    public abstract void a(int i);

    public abstract void a(View view);

    public abstract void a(CharSequence charsequence);

    public abstract void a(boolean flag);

    public Context b()
    {
        return null;
    }

    public abstract void b(int i);

    public abstract void b(boolean flag);

    public abstract void c(boolean flag);

    public abstract void d(boolean flag);

    public void e(boolean flag)
    {
    }
}
