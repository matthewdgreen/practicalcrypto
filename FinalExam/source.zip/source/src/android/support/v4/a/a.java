// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.a;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

// Referenced classes of package android.support.v4.a:
//            c, b

public class a
{

    public static boolean a(Context context, Intent aintent[], Bundle bundle)
    {
        int i = android.os.Build.VERSION.SDK_INT;
        if (i >= 16)
        {
            c.a(context, aintent, bundle);
            return true;
        }
        if (i >= 11)
        {
            b.a(context, aintent);
            return true;
        } else
        {
            return false;
        }
    }
}
