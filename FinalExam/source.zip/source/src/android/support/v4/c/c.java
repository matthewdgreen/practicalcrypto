// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.c;

import android.os.Parcel;

public interface c
{

    public abstract Object a(Parcel parcel, ClassLoader classloader);

    public abstract Object[] a(int i);
}
