// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.d;


public class c
{

    private static final Object a = new Object();
    private boolean b;
    private int c[];
    private Object d[];
    private int e;

    public c()
    {
        this(10);
    }

    public c(int i)
    {
        b = false;
        i = d(i);
        c = new int[i];
        d = new Object[i];
        e = 0;
    }

    static int c(int i)
    {
        int j = 4;
        do
        {
label0:
            {
                int k = i;
                if (j < 32)
                {
                    if (i > (1 << j) - 12)
                    {
                        break label0;
                    }
                    k = (1 << j) - 12;
                }
                return k;
            }
            j++;
        } while (true);
    }

    private void c()
    {
        int l = e;
        int ai[] = c;
        Object aobj[] = d;
        int i = 0;
        int j;
        int k;
        for (j = 0; i < l; j = k)
        {
            Object obj = aobj[i];
            k = j;
            if (obj != a)
            {
                if (i != j)
                {
                    ai[j] = ai[i];
                    aobj[j] = obj;
                }
                k = j + 1;
            }
            i++;
        }

        b = false;
        e = j;
    }

    static int d(int i)
    {
        return c(i * 4) / 4;
    }

    public int a()
    {
        if (b)
        {
            c();
        }
        return e;
    }

    public int a(int i)
    {
        if (b)
        {
            c();
        }
        return c[i];
    }

    public Object b(int i)
    {
        if (b)
        {
            c();
        }
        return d[i];
    }

    public void b()
    {
        int j = e;
        Object aobj[] = d;
        for (int i = 0; i < j; i++)
        {
            aobj[i] = null;
        }

        e = 0;
        b = false;
    }

}
