// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;


// Referenced classes of package android.support.v4.app:
//            Fragment

public abstract class aa
{

    public aa()
    {
    }

    public abstract int a();

    public abstract aa a(int i, Fragment fragment, String s);

    public abstract aa a(Fragment fragment);

    public abstract int b();

    public abstract aa b(Fragment fragment);
}
