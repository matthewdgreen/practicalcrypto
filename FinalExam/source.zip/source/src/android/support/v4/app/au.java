// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.app.Notification;

// Referenced classes of package android.support.v4.app:
//            ar, ap, ay

class au
    implements ar
{

    au()
    {
    }

    public Notification a(ap ap1)
    {
        return ay.a(ap1.a, ap1.r, ap1.b, ap1.c, ap1.h, ap1.f, ap1.i, ap1.d, ap1.e, ap1.g, ap1.n, ap1.o, ap1.p);
    }
}
