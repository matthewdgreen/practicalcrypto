// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.a.j;

public interface ac
{

    public abstract j a(int i, Bundle bundle);

    public abstract void a(j j);

    public abstract void a(j j, Object obj);
}
