// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

// Referenced classes of package android.support.v4.app:
//            f, d, e, Fragment, 
//            r

final class BackStackState
    implements Parcelable
{

    public static final android.os.Parcelable.Creator CREATOR = new f();
    final int a[];
    final int b;
    final int c;
    final String d;
    final int e;
    final int f;
    final CharSequence g;
    final int h;
    final CharSequence i;

    public BackStackState(Parcel parcel)
    {
        a = parcel.createIntArray();
        b = parcel.readInt();
        c = parcel.readInt();
        d = parcel.readString();
        e = parcel.readInt();
        f = parcel.readInt();
        g = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        h = parcel.readInt();
        i = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
    }

    public BackStackState(r r1, d d1)
    {
        r1 = d1.b;
        int j;
        int k;
        for (j = 0; r1 != null; j = k)
        {
            k = j;
            if (((e) (r1)).i != null)
            {
                k = j + ((e) (r1)).i.size();
            }
            r1 = ((e) (r1)).a;
        }

        a = new int[j + d1.d * 7];
        if (!d1.k)
        {
            throw new IllegalStateException("Not on back stack");
        }
        r1 = d1.b;
        j = 0;
        while (r1 != null) 
        {
            int ai[] = a;
            int l = j + 1;
            ai[j] = ((e) (r1)).c;
            ai = a;
            int i1 = l + 1;
            if (((e) (r1)).d != null)
            {
                j = ((e) (r1)).d.f;
            } else
            {
                j = -1;
            }
            ai[l] = j;
            ai = a;
            j = i1 + 1;
            ai[i1] = ((e) (r1)).e;
            ai = a;
            l = j + 1;
            ai[j] = ((e) (r1)).f;
            ai = a;
            j = l + 1;
            ai[l] = ((e) (r1)).g;
            ai = a;
            l = j + 1;
            ai[j] = ((e) (r1)).h;
            if (((e) (r1)).i != null)
            {
                int j1 = ((e) (r1)).i.size();
                int ai1[] = a;
                j = l + 1;
                ai1[l] = j1;
                for (l = 0; l < j1;)
                {
                    a[j] = ((Fragment)((e) (r1)).i.get(l)).f;
                    l++;
                    j++;
                }

            } else
            {
                int ai2[] = a;
                j = l + 1;
                ai2[l] = 0;
            }
            r1 = ((e) (r1)).a;
        }
        b = d1.i;
        c = d1.j;
        d = d1.m;
        e = d1.o;
        f = d1.p;
        g = d1.q;
        h = d1.r;
        i = d1.s;
    }

    public d a(r r1)
    {
        d d1 = new d(r1);
        int l = 0;
        for (int j = 0; j < a.length;)
        {
            e e1 = new e();
            int ai[] = a;
            int k = j + 1;
            e1.c = ai[j];
            if (r.a)
            {
                Log.v("FragmentManager", (new StringBuilder()).append("Instantiate ").append(d1).append(" op #").append(l).append(" base fragment #").append(a[k]).toString());
            }
            ai = a;
            j = k + 1;
            k = ai[k];
            int j1;
            if (k >= 0)
            {
                e1.d = (Fragment)r1.f.get(k);
            } else
            {
                e1.d = null;
            }
            ai = a;
            k = j + 1;
            e1.e = ai[j];
            ai = a;
            j = k + 1;
            e1.f = ai[k];
            ai = a;
            k = j + 1;
            e1.g = ai[j];
            ai = a;
            j = k + 1;
            e1.h = ai[k];
            ai = a;
            k = j + 1;
            j1 = ai[j];
            j = k;
            if (j1 > 0)
            {
                e1.i = new ArrayList(j1);
                int i1 = 0;
                do
                {
                    j = k;
                    if (i1 >= j1)
                    {
                        break;
                    }
                    if (r.a)
                    {
                        Log.v("FragmentManager", (new StringBuilder()).append("Instantiate ").append(d1).append(" set remove fragment #").append(a[k]).toString());
                    }
                    Fragment fragment = (Fragment)r1.f.get(a[k]);
                    e1.i.add(fragment);
                    i1++;
                    k++;
                } while (true);
            }
            d1.a(e1);
            l++;
        }

        d1.i = b;
        d1.j = c;
        d1.m = d;
        d1.o = e;
        d1.k = true;
        d1.p = f;
        d1.q = g;
        d1.r = h;
        d1.s = i;
        d1.a(1);
        return d1;
    }

    public int describeContents()
    {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int j)
    {
        parcel.writeIntArray(a);
        parcel.writeInt(b);
        parcel.writeInt(c);
        parcel.writeString(d);
        parcel.writeInt(e);
        parcel.writeInt(f);
        TextUtils.writeToParcel(g, parcel, 0);
        parcel.writeInt(h);
        TextUtils.writeToParcel(i, parcel, 0);
    }

}
