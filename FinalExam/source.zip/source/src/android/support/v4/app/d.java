// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.support.v4.d.b;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

// Referenced classes of package android.support.v4.app:
//            aa, Fragment, e, r

final class d extends aa
    implements Runnable
{

    final r a;
    e b;
    e c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    boolean k;
    boolean l;
    String m;
    boolean n;
    int o;
    int p;
    CharSequence q;
    int r;
    CharSequence s;

    public d(r r1)
    {
        l = true;
        o = -1;
        a = r1;
    }

    private void a(int i1, Fragment fragment, String s1, int j1)
    {
        fragment.s = a;
        if (s1 != null)
        {
            if (fragment.y != null && !s1.equals(fragment.y))
            {
                throw new IllegalStateException((new StringBuilder()).append("Can't change tag of fragment ").append(fragment).append(": was ").append(fragment.y).append(" now ").append(s1).toString());
            }
            fragment.y = s1;
        }
        if (i1 != 0)
        {
            if (fragment.w != 0 && fragment.w != i1)
            {
                throw new IllegalStateException((new StringBuilder()).append("Can't change container ID of fragment ").append(fragment).append(": was ").append(fragment.w).append(" now ").append(i1).toString());
            }
            fragment.w = i1;
            fragment.x = i1;
        }
        s1 = new e();
        s1.c = j1;
        s1.d = fragment;
        a(((e) (s1)));
    }

    public int a()
    {
        return a(false);
    }

    int a(boolean flag)
    {
        if (n)
        {
            throw new IllegalStateException("commit already called");
        }
        if (r.a)
        {
            Log.v("FragmentManager", (new StringBuilder()).append("Commit: ").append(this).toString());
            a("  ", ((FileDescriptor) (null)), new PrintWriter(new b("FragmentManager")), ((String []) (null)));
        }
        n = true;
        if (k)
        {
            o = a.a(this);
        } else
        {
            o = -1;
        }
        a.a(this, flag);
        return o;
    }

    public aa a(int i1, Fragment fragment, String s1)
    {
        a(i1, fragment, s1, 1);
        return this;
    }

    public aa a(Fragment fragment)
    {
        e e1 = new e();
        e1.c = 6;
        e1.d = fragment;
        a(e1);
        return this;
    }

    void a(int i1)
    {
        if (k)
        {
            if (r.a)
            {
                Log.v("FragmentManager", (new StringBuilder()).append("Bump nesting in ").append(this).append(" by ").append(i1).toString());
            }
            e e1 = b;
            while (e1 != null) 
            {
                if (e1.d != null)
                {
                    Fragment fragment = e1.d;
                    fragment.r = fragment.r + i1;
                    if (r.a)
                    {
                        Log.v("FragmentManager", (new StringBuilder()).append("Bump nesting of ").append(e1.d).append(" to ").append(e1.d.r).toString());
                    }
                }
                if (e1.i != null)
                {
                    for (int j1 = e1.i.size() - 1; j1 >= 0; j1--)
                    {
                        Fragment fragment1 = (Fragment)e1.i.get(j1);
                        fragment1.r = fragment1.r + i1;
                        if (r.a)
                        {
                            Log.v("FragmentManager", (new StringBuilder()).append("Bump nesting of ").append(fragment1).append(" to ").append(fragment1.r).toString());
                        }
                    }

                }
                e1 = e1.a;
            }
        }
    }

    void a(e e1)
    {
        if (b == null)
        {
            c = e1;
            b = e1;
        } else
        {
            e1.b = c;
            c.a = e1;
            c = e1;
        }
        e1.e = e;
        e1.f = f;
        e1.g = g;
        e1.h = h;
        d = d + 1;
    }

    public void a(String s1, FileDescriptor filedescriptor, PrintWriter printwriter, String as[])
    {
        a(s1, printwriter, true);
    }

    public void a(String s1, PrintWriter printwriter, boolean flag)
    {
        e e1;
        String s3;
        int i1;
        if (flag)
        {
            printwriter.print(s1);
            printwriter.print("mName=");
            printwriter.print(m);
            printwriter.print(" mIndex=");
            printwriter.print(o);
            printwriter.print(" mCommitted=");
            printwriter.println(n);
            if (i != 0)
            {
                printwriter.print(s1);
                printwriter.print("mTransition=#");
                printwriter.print(Integer.toHexString(i));
                printwriter.print(" mTransitionStyle=#");
                printwriter.println(Integer.toHexString(j));
            }
            if (e != 0 || f != 0)
            {
                printwriter.print(s1);
                printwriter.print("mEnterAnim=#");
                printwriter.print(Integer.toHexString(e));
                printwriter.print(" mExitAnim=#");
                printwriter.println(Integer.toHexString(f));
            }
            if (g != 0 || h != 0)
            {
                printwriter.print(s1);
                printwriter.print("mPopEnterAnim=#");
                printwriter.print(Integer.toHexString(g));
                printwriter.print(" mPopExitAnim=#");
                printwriter.println(Integer.toHexString(h));
            }
            if (p != 0 || q != null)
            {
                printwriter.print(s1);
                printwriter.print("mBreadCrumbTitleRes=#");
                printwriter.print(Integer.toHexString(p));
                printwriter.print(" mBreadCrumbTitleText=");
                printwriter.println(q);
            }
            if (r != 0 || s != null)
            {
                printwriter.print(s1);
                printwriter.print("mBreadCrumbShortTitleRes=#");
                printwriter.print(Integer.toHexString(r));
                printwriter.print(" mBreadCrumbShortTitleText=");
                printwriter.println(s);
            }
        }
        if (b == null)
        {
            break MISSING_BLOCK_LABEL_811;
        }
        printwriter.print(s1);
        printwriter.println("Operations:");
        s3 = (new StringBuilder()).append(s1).append("    ").toString();
        e1 = b;
        i1 = 0;
_L13:
        if (e1 == null) goto _L2; else goto _L1
_L1:
        e1.c;
        JVM INSTR tableswitch 0 7: default 412
    //                   0 690
    //                   1 698
    //                   2 706
    //                   3 714
    //                   4 722
    //                   5 730
    //                   6 738
    //                   7 746;
           goto _L3 _L4 _L5 _L6 _L7 _L8 _L9 _L10 _L11
_L11:
        break MISSING_BLOCK_LABEL_746;
_L3:
        String s2 = (new StringBuilder()).append("cmd=").append(e1.c).toString();
_L12:
        printwriter.print(s1);
        printwriter.print("  Op #");
        printwriter.print(i1);
        printwriter.print(": ");
        printwriter.print(s2);
        printwriter.print(" ");
        printwriter.println(e1.d);
        if (flag)
        {
            if (e1.e != 0 || e1.f != 0)
            {
                printwriter.print(s1);
                printwriter.print("enterAnim=#");
                printwriter.print(Integer.toHexString(e1.e));
                printwriter.print(" exitAnim=#");
                printwriter.println(Integer.toHexString(e1.f));
            }
            if (e1.g != 0 || e1.h != 0)
            {
                printwriter.print(s1);
                printwriter.print("popEnterAnim=#");
                printwriter.print(Integer.toHexString(e1.g));
                printwriter.print(" popExitAnim=#");
                printwriter.println(Integer.toHexString(e1.h));
            }
        }
        if (e1.i != null && e1.i.size() > 0)
        {
            int j1 = 0;
            while (j1 < e1.i.size()) 
            {
                printwriter.print(s3);
                if (e1.i.size() == 1)
                {
                    printwriter.print("Removed: ");
                } else
                {
                    if (j1 == 0)
                    {
                        printwriter.println("Removed:");
                    }
                    printwriter.print(s3);
                    printwriter.print("  #");
                    printwriter.print(j1);
                    printwriter.print(": ");
                }
                printwriter.println(e1.i.get(j1));
                j1++;
            }
        }
        break MISSING_BLOCK_LABEL_795;
_L4:
        s2 = "NULL";
          goto _L12
_L5:
        s2 = "ADD";
          goto _L12
_L6:
        s2 = "REPLACE";
          goto _L12
_L7:
        s2 = "REMOVE";
          goto _L12
_L8:
        s2 = "HIDE";
          goto _L12
_L9:
        s2 = "SHOW";
          goto _L12
_L10:
        s2 = "DETACH";
          goto _L12
        s2 = "ATTACH";
          goto _L12
        e1 = e1.a;
        i1++;
          goto _L13
_L2:
    }

    public int b()
    {
        return a(true);
    }

    public aa b(Fragment fragment)
    {
        e e1 = new e();
        e1.c = 7;
        e1.d = fragment;
        a(e1);
        return this;
    }

    public void b(boolean flag)
    {
        e e1;
        if (r.a)
        {
            Log.v("FragmentManager", (new StringBuilder()).append("popFromBackStack: ").append(this).toString());
            a("  ", ((FileDescriptor) (null)), new PrintWriter(new b("FragmentManager")), ((String []) (null)));
        }
        a(-1);
        e1 = c;
_L10:
        if (e1 == null)
        {
            break MISSING_BLOCK_LABEL_449;
        }
        e1.c;
        JVM INSTR tableswitch 1 7: default 116
    //                   1 147
    //                   2 187
    //                   3 284
    //                   4 309
    //                   5 344
    //                   6 379
    //                   7 414;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_414;
_L3:
        break; /* Loop/switch isn't completed */
_L1:
        throw new IllegalArgumentException((new StringBuilder()).append("Unknown cmd: ").append(e1.c).toString());
_L2:
        Fragment fragment = e1.d;
        fragment.G = e1.h;
        a.a(fragment, android.support.v4.app.r.c(i), j);
_L11:
        e1 = e1.b;
        if (true) goto _L10; else goto _L9
_L9:
        Fragment fragment1 = e1.d;
        if (fragment1 != null)
        {
            fragment1.G = e1.h;
            a.a(fragment1, android.support.v4.app.r.c(i), j);
        }
        if (e1.i != null)
        {
            int i1 = 0;
            while (i1 < e1.i.size()) 
            {
                Fragment fragment2 = (Fragment)e1.i.get(i1);
                fragment2.G = e1.g;
                a.a(fragment2, false);
                i1++;
            }
        }
          goto _L11
_L4:
        Fragment fragment3 = e1.d;
        fragment3.G = e1.g;
        a.a(fragment3, false);
          goto _L11
_L5:
        Fragment fragment4 = e1.d;
        fragment4.G = e1.g;
        a.c(fragment4, android.support.v4.app.r.c(i), j);
          goto _L11
_L6:
        Fragment fragment5 = e1.d;
        fragment5.G = e1.h;
        a.b(fragment5, android.support.v4.app.r.c(i), j);
          goto _L11
_L7:
        Fragment fragment6 = e1.d;
        fragment6.G = e1.g;
        a.e(fragment6, android.support.v4.app.r.c(i), j);
          goto _L11
        Fragment fragment7 = e1.d;
        fragment7.G = e1.g;
        a.d(fragment7, android.support.v4.app.r.c(i), j);
          goto _L11
        if (flag)
        {
            a.a(a.n, android.support.v4.app.r.c(i), j, true);
        }
        if (o >= 0)
        {
            a.b(o);
            o = -1;
        }
        return;
    }

    public String c()
    {
        return m;
    }

    public void run()
    {
        e e1;
        if (r.a)
        {
            Log.v("FragmentManager", (new StringBuilder()).append("Run: ").append(this).toString());
        }
        if (k && o < 0)
        {
            throw new IllegalStateException("addToBackStack() called after commit()");
        }
        a(1);
        e1 = b;
_L10:
        if (e1 == null)
        {
            break MISSING_BLOCK_LABEL_623;
        }
        e1.c;
        JVM INSTR tableswitch 1 7: default 116
    //                   1 147
    //                   2 177
    //                   3 463
    //                   4 495
    //                   5 527
    //                   6 559
    //                   7 591;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_591;
_L3:
        break; /* Loop/switch isn't completed */
_L1:
        throw new IllegalArgumentException((new StringBuilder()).append("Unknown cmd: ").append(e1.c).toString());
_L2:
        Fragment fragment = e1.d;
        fragment.G = e1.e;
        a.a(fragment, false);
_L11:
        e1 = e1.a;
        if (true) goto _L10; else goto _L9
_L9:
        Fragment fragment1 = e1.d;
        Fragment fragment7;
        if (a.g != null)
        {
            int i1 = 0;
label0:
            do
            {
label1:
                {
                    fragment7 = fragment1;
                    if (i1 >= a.g.size())
                    {
                        break label0;
                    }
                    Fragment fragment8 = (Fragment)a.g.get(i1);
                    if (r.a)
                    {
                        Log.v("FragmentManager", (new StringBuilder()).append("OP_REPLACE: adding=").append(fragment1).append(" old=").append(fragment8).toString());
                    }
                    if (fragment1 != null)
                    {
                        fragment7 = fragment1;
                        if (fragment8.x != fragment1.x)
                        {
                            break label1;
                        }
                    }
                    if (fragment8 == fragment1)
                    {
                        fragment7 = null;
                        e1.d = null;
                    } else
                    {
                        if (e1.i == null)
                        {
                            e1.i = new ArrayList();
                        }
                        e1.i.add(fragment8);
                        fragment8.G = e1.f;
                        if (k)
                        {
                            fragment8.r = fragment8.r + 1;
                            if (r.a)
                            {
                                Log.v("FragmentManager", (new StringBuilder()).append("Bump nesting of ").append(fragment8).append(" to ").append(fragment8.r).toString());
                            }
                        }
                        a.a(fragment8, i, j);
                        fragment7 = fragment1;
                    }
                }
                i1++;
                fragment1 = fragment7;
            } while (true);
        } else
        {
            fragment7 = fragment1;
        }
        if (fragment7 != null)
        {
            fragment7.G = e1.e;
            a.a(fragment7, false);
        }
          goto _L11
_L4:
        Fragment fragment2 = e1.d;
        fragment2.G = e1.f;
        a.a(fragment2, i, j);
          goto _L11
_L5:
        Fragment fragment3 = e1.d;
        fragment3.G = e1.f;
        a.b(fragment3, i, j);
          goto _L11
_L6:
        Fragment fragment4 = e1.d;
        fragment4.G = e1.e;
        a.c(fragment4, i, j);
          goto _L11
_L7:
        Fragment fragment5 = e1.d;
        fragment5.G = e1.f;
        a.d(fragment5, i, j);
          goto _L11
        Fragment fragment6 = e1.d;
        fragment6.G = e1.e;
        a.e(fragment6, i, j);
          goto _L11
        a.a(a.n, i, j, true);
        if (k)
        {
            a.b(this);
        }
        return;
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder(128);
        stringbuilder.append("BackStackEntry{");
        stringbuilder.append(Integer.toHexString(System.identityHashCode(this)));
        if (o >= 0)
        {
            stringbuilder.append(" #");
            stringbuilder.append(o);
        }
        if (m != null)
        {
            stringbuilder.append(" ");
            stringbuilder.append(m);
        }
        stringbuilder.append("}");
        return stringbuilder.toString();
    }
}
