// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.os.Bundle;

// Referenced classes of package android.support.v4.app:
//            Fragment

final class z
{

    private final String a;
    private final Class b;
    private final Bundle c;
    private Fragment d;

    static Fragment a(z z1)
    {
        return z1.d;
    }

    static Fragment a(z z1, Fragment fragment)
    {
        z1.d = fragment;
        return fragment;
    }

    static String b(z z1)
    {
        return z1.a;
    }

    static Class c(z z1)
    {
        return z1.b;
    }

    static Bundle d(z z1)
    {
        return z1.c;
    }
}
