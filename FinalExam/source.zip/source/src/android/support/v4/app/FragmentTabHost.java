// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.content.Context;
import android.os.Parcelable;
import android.widget.TabHost;
import java.util.ArrayList;

// Referenced classes of package android.support.v4.app:
//            z, p, aa, Fragment

public class FragmentTabHost extends TabHost
    implements android.widget.TabHost.OnTabChangeListener
{

    private final ArrayList a;
    private Context b;
    private p c;
    private int d;
    private android.widget.TabHost.OnTabChangeListener e;
    private z f;
    private boolean g;

    private aa a(String s, aa aa1)
    {
        z z1 = null;
        for (int i = 0; i < a.size(); i++)
        {
            z z2 = (z)a.get(i);
            if (z.b(z2).equals(s))
            {
                z1 = z2;
            }
        }

        if (z1 == null)
        {
            throw new IllegalStateException((new StringBuilder()).append("No tab known for tag ").append(s).toString());
        }
        s = aa1;
        if (f != z1)
        {
            s = aa1;
            if (aa1 == null)
            {
                s = c.a();
            }
            if (f != null && z.a(f) != null)
            {
                s.a(z.a(f));
            }
            if (z1 != null)
            {
                if (z.a(z1) == null)
                {
                    z.a(z1, Fragment.a(b, z.c(z1).getName(), z.d(z1)));
                    s.a(d, z.a(z1), z.b(z1));
                } else
                {
                    s.b(z.a(z1));
                }
            }
            f = z1;
        }
        return s;
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        String s = getCurrentTabTag();
        aa aa1 = null;
        int i = 0;
        while (i < a.size()) 
        {
            z z1 = (z)a.get(i);
            z.a(z1, c.a(z.b(z1)));
            aa aa2 = aa1;
            if (z.a(z1) != null)
            {
                aa2 = aa1;
                if (!z.a(z1).e())
                {
                    if (z.b(z1).equals(s))
                    {
                        f = z1;
                        aa2 = aa1;
                    } else
                    {
                        aa2 = aa1;
                        if (aa1 == null)
                        {
                            aa2 = c.a();
                        }
                        aa2.a(z.a(z1));
                    }
                }
            }
            i++;
            aa1 = aa2;
        }
        g = true;
        aa1 = a(s, aa1);
        if (aa1 != null)
        {
            aa1.a();
            c.b();
        }
    }

    protected void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        g = false;
    }

    protected void onRestoreInstanceState(Parcelable parcelable)
    {
        parcelable = (SavedState)parcelable;
        super.onRestoreInstanceState(parcelable.getSuperState());
        setCurrentTabByTag(((SavedState) (parcelable)).a);
    }

    protected Parcelable onSaveInstanceState()
    {
        SavedState savedstate = new SavedState(super.onSaveInstanceState());
        savedstate.a = getCurrentTabTag();
        return savedstate;
    }

    public void onTabChanged(String s)
    {
        if (g)
        {
            aa aa1 = a(s, null);
            if (aa1 != null)
            {
                aa1.a();
            }
        }
        if (e != null)
        {
            e.onTabChanged(s);
        }
    }

    public void setOnTabChangedListener(android.widget.TabHost.OnTabChangeListener ontabchangelistener)
    {
        e = ontabchangelistener;
    }

    public void setup()
    {
        throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
    }

    private class SavedState extends android.view.View.BaseSavedState
    {

        public static final android.os.Parcelable.Creator CREATOR = new y();
        String a;

        public String toString()
        {
            return (new StringBuilder()).append("FragmentTabHost.SavedState{").append(Integer.toHexString(System.identityHashCode(this))).append(" curTab=").append(a).append("}").toString();
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            super.writeToParcel(parcel, i);
            parcel.writeString(a);
        }


        private SavedState(Parcel parcel)
        {
            super(parcel);
            a = parcel.readString();
        }

        SavedState(Parcel parcel, x x)
        {
            this(parcel);
        }

        SavedState(Parcelable parcelable)
        {
            super(parcelable);
        }
    }

}
