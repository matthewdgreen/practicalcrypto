// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.view.View;

public interface g
{

    public abstract void a(int i);

    public abstract void a(View view);

    public abstract void a(View view, float f);

    public abstract void b(View view);
}
