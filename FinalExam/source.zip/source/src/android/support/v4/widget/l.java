// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;

// Referenced classes of package android.support.v4.widget:
//            n

class l
    implements n
{

    l()
    {
    }

    public Object a(Context context)
    {
        return null;
    }

    public void a(Object obj, int i, int j)
    {
    }

    public boolean a(Object obj)
    {
        return true;
    }

    public boolean a(Object obj, float f)
    {
        return false;
    }

    public boolean a(Object obj, Canvas canvas)
    {
        return false;
    }

    public void b(Object obj)
    {
    }

    public boolean c(Object obj)
    {
        return false;
    }
}
