// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;

interface n
{

    public abstract Object a(Context context);

    public abstract void a(Object obj, int i, int j);

    public abstract boolean a(Object obj);

    public abstract boolean a(Object obj, float f);

    public abstract boolean a(Object obj, Canvas canvas);

    public abstract void b(Object obj);

    public abstract boolean c(Object obj);
}
