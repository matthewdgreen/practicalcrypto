// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.view.View;

public abstract class ah
{

    public int a(View view)
    {
        return 0;
    }

    public int a(View view, int i, int j)
    {
        return 0;
    }

    public void a(int i)
    {
    }

    public void a(int i, int j)
    {
    }

    public void a(View view, float f, float f1)
    {
    }

    public void a(View view, int i, int j, int k, int l)
    {
    }

    public abstract boolean a(View view, int i);

    public int b(View view)
    {
        return 0;
    }

    public int b(View view, int i, int j)
    {
        return 0;
    }

    public void b(int i, int j)
    {
    }

    public void b(View view, int i)
    {
    }

    public boolean b(int i)
    {
        return false;
    }

    public int c(int i)
    {
        return i;
    }
}
