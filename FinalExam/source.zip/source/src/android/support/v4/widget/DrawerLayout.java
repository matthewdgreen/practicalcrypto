// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.support.v4.view.aj;
import android.support.v4.view.au;
import android.support.v4.view.q;
import android.support.v4.view.v;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

// Referenced classes of package android.support.v4.widget:
//            h, af, g, j

public class DrawerLayout extends ViewGroup
{

    private static final int a[] = {
        0x10100b3
    };
    private int b;
    private int c;
    private float d;
    private Paint e;
    private final af f;
    private final af g;
    private final j h;
    private final j i;
    private int j;
    private boolean k;
    private boolean l;
    private int m;
    private int n;
    private boolean o;
    private boolean p;
    private g q;
    private float r;
    private float s;
    private Drawable t;
    private Drawable u;

    static String b(int i1)
    {
        if ((i1 & 3) == 3)
        {
            return "LEFT";
        }
        if ((i1 & 5) == 5)
        {
            return "RIGHT";
        } else
        {
            return Integer.toHexString(i1);
        }
    }

    static int[] c()
    {
        return a;
    }

    private boolean d()
    {
        int j1 = getChildCount();
        for (int i1 = 0; i1 < j1; i1++)
        {
            if (((h)getChildAt(i1).getLayoutParams()).c)
            {
                return true;
            }
        }

        return false;
    }

    private boolean e()
    {
        return f() != null;
    }

    private View f()
    {
        int j1 = getChildCount();
        for (int i1 = 0; i1 < j1; i1++)
        {
            View view = getChildAt(i1);
            if (g(view) && j(view))
            {
                return view;
            }
        }

        return null;
    }

    private static boolean k(View view)
    {
        boolean flag1 = false;
        view = view.getBackground();
        boolean flag = flag1;
        if (view != null)
        {
            flag = flag1;
            if (view.getOpacity() == -1)
            {
                flag = true;
            }
        }
        return flag;
    }

    public int a(View view)
    {
        int i1 = e(view);
        if (i1 == 3)
        {
            return m;
        }
        if (i1 == 5)
        {
            return n;
        } else
        {
            return 0;
        }
    }

    View a()
    {
        int j1 = getChildCount();
        for (int i1 = 0; i1 < j1; i1++)
        {
            View view = getChildAt(i1);
            if (((h)view.getLayoutParams()).d)
            {
                return view;
            }
        }

        return null;
    }

    View a(int i1)
    {
        int k1 = getChildCount();
        for (int j1 = 0; j1 < k1; j1++)
        {
            View view = getChildAt(j1);
            if ((e(view) & 7) == (i1 & 7))
            {
                return view;
            }
        }

        return null;
    }

    public void a(int i1, int j1)
    {
        j1 = android.support.v4.view.q.a(j1, au.e(this));
        if (j1 == 3)
        {
            m = i1;
        } else
        if (j1 == 5)
        {
            n = i1;
        }
        if (i1 != 0)
        {
            af af1;
            if (j1 == 3)
            {
                af1 = f;
            } else
            {
                af1 = g;
            }
            af1.e();
        }
        i1;
        JVM INSTR tableswitch 1 2: default 60
    //                   1 98
    //                   2 82;
           goto _L1 _L2 _L3
_L1:
        View view;
        return;
_L3:
        if ((view = a(j1)) != null)
        {
            h(view);
            return;
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if ((view = a(j1)) != null)
        {
            i(view);
            return;
        }
        if (true) goto _L1; else goto _L4
_L4:
    }

    void a(int i1, int j1, View view)
    {
        h h1;
        boolean flag = true;
        int k1 = f.a();
        int l1 = g.a();
        i1 = ((flag) ? 1 : 0);
        if (k1 != 1)
        {
            if (l1 == 1)
            {
                i1 = ((flag) ? 1 : 0);
            } else
            if (k1 == 2 || l1 == 2)
            {
                i1 = 2;
            } else
            {
                i1 = 0;
            }
        }
        if (view == null || j1 != 0) goto _L2; else goto _L1
_L1:
        h1 = (h)view.getLayoutParams();
        if (h1.b != 0.0F) goto _L4; else goto _L3
_L3:
        b(view);
_L2:
        if (i1 != j)
        {
            j = i1;
            if (q != null)
            {
                q.a(i1);
            }
        }
        return;
_L4:
        if (h1.b == 1.0F)
        {
            c(view);
        }
        if (true) goto _L2; else goto _L5
_L5:
    }

    void a(View view, float f1)
    {
        if (q != null)
        {
            q.a(view, f1);
        }
    }

    void a(boolean flag)
    {
        int k1 = getChildCount();
        int i1 = 0;
        boolean flag1 = false;
        while (i1 < k1) 
        {
            View view = getChildAt(i1);
            h h1 = (h)view.getLayoutParams();
            int j1 = ((flag1) ? 1 : 0);
            if (g(view))
            {
                if (flag && !h1.c)
                {
                    j1 = ((flag1) ? 1 : 0);
                } else
                {
                    j1 = view.getWidth();
                    if (a(view, 3))
                    {
                        flag1 |= f.a(view, -j1, view.getTop());
                    } else
                    {
                        flag1 |= g.a(view, getWidth(), view.getTop());
                    }
                    h1.c = false;
                    j1 = ((flag1) ? 1 : 0);
                }
            }
            i1++;
            flag1 = j1;
        }
        h.a();
        i.a();
        if (flag1)
        {
            invalidate();
        }
    }

    boolean a(View view, int i1)
    {
        return (e(view) & i1) == i1;
    }

    public void b()
    {
        a(false);
    }

    void b(View view)
    {
        h h1 = (h)view.getLayoutParams();
        if (h1.d)
        {
            h1.d = false;
            if (q != null)
            {
                q.b(view);
            }
            sendAccessibilityEvent(32);
        }
    }

    void b(View view, float f1)
    {
        h h1 = (h)view.getLayoutParams();
        if (f1 == h1.b)
        {
            return;
        } else
        {
            h1.b = f1;
            a(view, f1);
            return;
        }
    }

    void c(View view)
    {
        h h1 = (h)view.getLayoutParams();
        if (!h1.d)
        {
            h1.d = true;
            if (q != null)
            {
                q.a(view);
            }
            view.sendAccessibilityEvent(32);
        }
    }

    protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutparams)
    {
        return (layoutparams instanceof h) && super.checkLayoutParams(layoutparams);
    }

    public void computeScroll()
    {
        int j1 = getChildCount();
        float f1 = 0.0F;
        for (int i1 = 0; i1 < j1; i1++)
        {
            f1 = Math.max(f1, ((h)getChildAt(i1).getLayoutParams()).b);
        }

        d = f1;
        if (f.a(true) | g.a(true))
        {
            au.b(this);
        }
    }

    float d(View view)
    {
        return ((h)view.getLayoutParams()).b;
    }

    protected boolean drawChild(Canvas canvas, View view, long l1)
    {
        int i1;
        int j1;
        int k1;
        int i2;
        int i3;
        int j3;
        int k3;
        boolean flag1;
        i3 = getHeight();
        flag1 = f(view);
        k1 = 0;
        boolean flag = false;
        i1 = getWidth();
        j3 = canvas.save();
        j1 = i1;
        if (!flag1)
        {
            break MISSING_BLOCK_LABEL_220;
        }
        k3 = getChildCount();
        i2 = 0;
        k1 = ((flag) ? 1 : 0);
_L2:
        if (i2 >= k3)
        {
            break MISSING_BLOCK_LABEL_202;
        }
        View view1 = getChildAt(i2);
        if (view1 == view || view1.getVisibility() != 0 || !k(view1) || !g(view1))
        {
            break; /* Loop/switch isn't completed */
        }
        int k2;
        if (view1.getHeight() < i3)
        {
            k2 = k1;
            j1 = i1;
        } else
        {
label0:
            {
                if (!a(view1, 3))
                {
                    break label0;
                }
                j1 = view1.getRight();
                float f1;
                int j2;
                int l2;
                boolean flag2;
                if (j1 <= k1)
                {
                    j1 = k1;
                }
                k2 = j1;
                j1 = i1;
            }
        }
_L3:
        i2++;
        i1 = j1;
        k1 = k2;
        if (true) goto _L2; else goto _L1
        l2 = view1.getLeft();
        j1 = l2;
        k2 = k1;
        if (l2 < i1) goto _L3; else goto _L1
_L1:
        j1 = i1;
        k2 = k1;
          goto _L3
        canvas.clipRect(k1, 0, i1, getHeight());
        j1 = i1;
        flag2 = super.drawChild(canvas, view, l1);
        canvas.restoreToCount(j3);
        if (d > 0.0F && flag1)
        {
            i1 = (int)((float)((c & 0xff000000) >>> 24) * d);
            j2 = c;
            e.setColor(i1 << 24 | j2 & 0xffffff);
            canvas.drawRect(k1, 0.0F, j1, getHeight(), e);
        } else
        {
            if (t != null && a(view, 3))
            {
                i1 = t.getIntrinsicWidth();
                j1 = view.getRight();
                k1 = f.b();
                f1 = Math.max(0.0F, Math.min((float)j1 / (float)k1, 1.0F));
                t.setBounds(j1, view.getTop(), i1 + j1, view.getBottom());
                t.setAlpha((int)(255F * f1));
                t.draw(canvas);
                return flag2;
            }
            if (u != null && a(view, 5))
            {
                i1 = u.getIntrinsicWidth();
                j1 = view.getLeft();
                k1 = getWidth();
                j2 = g.b();
                f1 = Math.max(0.0F, Math.min((float)(k1 - j1) / (float)j2, 1.0F));
                u.setBounds(j1 - i1, view.getTop(), j1, view.getBottom());
                u.setAlpha((int)(255F * f1));
                u.draw(canvas);
                return flag2;
            }
        }
        return flag2;
    }

    int e(View view)
    {
        return android.support.v4.view.q.a(((h)view.getLayoutParams()).a, au.e(view));
    }

    boolean f(View view)
    {
        return ((h)view.getLayoutParams()).a == 0;
    }

    boolean g(View view)
    {
        return (android.support.v4.view.q.a(((h)view.getLayoutParams()).a, au.e(view)) & 7) != 0;
    }

    protected android.view.ViewGroup.LayoutParams generateDefaultLayoutParams()
    {
        return new h(-1, -1);
    }

    public android.view.ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeset)
    {
        return new h(getContext(), attributeset);
    }

    protected android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutparams)
    {
        if (layoutparams instanceof h)
        {
            return new h((h)layoutparams);
        }
        if (layoutparams instanceof android.view.ViewGroup.MarginLayoutParams)
        {
            return new h((android.view.ViewGroup.MarginLayoutParams)layoutparams);
        } else
        {
            return new h(layoutparams);
        }
    }

    public void h(View view)
    {
        if (!g(view))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("View ").append(view).append(" is not a sliding drawer").toString());
        }
        if (l)
        {
            view = (h)view.getLayoutParams();
            view.b = 1.0F;
            view.d = true;
        } else
        if (a(view, 3))
        {
            f.a(view, 0, view.getTop());
        } else
        {
            g.a(view, getWidth() - view.getWidth(), view.getTop());
        }
        invalidate();
    }

    public void i(View view)
    {
        if (!g(view))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("View ").append(view).append(" is not a sliding drawer").toString());
        }
        if (l)
        {
            view = (h)view.getLayoutParams();
            view.b = 0.0F;
            view.d = false;
        } else
        if (a(view, 3))
        {
            f.a(view, -view.getWidth(), view.getTop());
        } else
        {
            g.a(view, getWidth(), view.getTop());
        }
        invalidate();
    }

    public boolean j(View view)
    {
        if (!g(view))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("View ").append(view).append(" is not a drawer").toString());
        }
        return ((h)view.getLayoutParams()).b > 0.0F;
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        l = true;
    }

    protected void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        l = true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionevent)
    {
        int i1;
        boolean flag1;
        boolean flag2;
        boolean flag3;
        flag1 = false;
        i1 = aj.a(motionevent);
        flag2 = f.a(motionevent);
        flag3 = g.a(motionevent);
        i1;
        JVM INSTR tableswitch 0 3: default 60
    //                   0 96
    //                   1 190
    //                   2 159
    //                   3 190;
           goto _L1 _L2 _L3 _L4 _L3
_L1:
        boolean flag = false;
_L5:
        if (flag2 | flag3 || flag || d() || p)
        {
            flag1 = true;
        }
        return flag1;
_L2:
        float f1 = motionevent.getX();
        float f2 = motionevent.getY();
        r = f1;
        s = f2;
        if (d > 0.0F && f(f.d((int)f1, (int)f2)))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        o = false;
        p = false;
        continue; /* Loop/switch isn't completed */
_L4:
        if (!f.c(3))
        {
            continue; /* Loop/switch isn't completed */
        }
        h.a();
        i.a();
        flag = false;
        if (true) goto _L5; else goto _L3
_L3:
        a(true);
        o = false;
        p = false;
        if (true) goto _L1; else goto _L6
_L6:
    }

    public boolean onKeyDown(int i1, KeyEvent keyevent)
    {
        if (i1 == 4 && e())
        {
            v.b(keyevent);
            return true;
        } else
        {
            return super.onKeyDown(i1, keyevent);
        }
    }

    public boolean onKeyUp(int i1, KeyEvent keyevent)
    {
        if (i1 == 4)
        {
            keyevent = f();
            if (keyevent != null && a(keyevent) == 0)
            {
                b();
            }
            return keyevent != null;
        } else
        {
            return super.onKeyUp(i1, keyevent);
        }
    }

    protected void onLayout(boolean flag, int i1, int j1, int k1, int l1)
    {
        int k2;
        int l2;
        k = true;
        k2 = k1 - i1;
        l2 = getChildCount();
        k1 = 0;
_L2:
        View view;
        if (k1 >= l2)
        {
            break MISSING_BLOCK_LABEL_444;
        }
        view = getChildAt(k1);
        if (view.getVisibility() != 8)
        {
            break; /* Loop/switch isn't completed */
        }
_L3:
        k1++;
        if (true) goto _L2; else goto _L1
_L1:
        h h1;
label0:
        {
            h1 = (h)view.getLayoutParams();
            if (!f(view))
            {
                break label0;
            }
            view.layout(h1.leftMargin, h1.topMargin, h1.leftMargin + view.getMeasuredWidth(), h1.topMargin + view.getMeasuredHeight());
        }
          goto _L3
        int i2;
        int i3;
        int j3;
        i3 = view.getMeasuredWidth();
        j3 = view.getMeasuredHeight();
        float f1;
        boolean flag1;
        if (a(view, 3))
        {
            i1 = -i3;
            i2 = (int)((float)i3 * h1.b) + i1;
            f1 = (float)(i3 + i2) / (float)i3;
        } else
        {
            i2 = k2 - (int)((float)i3 * h1.b);
            f1 = (float)(k2 - i2) / (float)i3;
        }
        if (f1 != h1.b)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        h1.a & 0x70;
        JVM INSTR lookupswitch 2: default 216
    //                   16: 354
    //                   80: 314;
           goto _L4 _L5 _L6
_L5:
        break MISSING_BLOCK_LABEL_354;
_L4:
        view.layout(i2, h1.topMargin, i3 + i2, j3);
_L7:
        if (flag1)
        {
            b(view, f1);
        }
        int j2;
        int k3;
        if (h1.b > 0.0F)
        {
            i1 = 0;
        } else
        {
            i1 = 4;
        }
        if (view.getVisibility() != i1)
        {
            view.setVisibility(i1);
        }
          goto _L3
_L6:
        i1 = l1 - j1;
        view.layout(i2, i1 - h1.bottomMargin - view.getMeasuredHeight(), i3 + i2, i1 - h1.bottomMargin);
          goto _L7
        k3 = l1 - j1;
        j2 = (k3 - j3) / 2;
        if (j2 < h1.topMargin)
        {
            i1 = h1.topMargin;
        } else
        {
            i1 = j2;
            if (j2 + j3 > k3 - h1.bottomMargin)
            {
                i1 = k3 - h1.bottomMargin - j3;
            }
        }
        view.layout(i2, i1, i3 + i2, j3 + i1);
          goto _L7
        k = false;
        l = false;
        return;
          goto _L3
    }

    protected void onMeasure(int i1, int j1)
    {
        int l1;
        int i2;
        int j2;
        int k2;
        int i3;
        i2 = 300;
        i3 = android.view.View.MeasureSpec.getMode(i1);
        k2 = android.view.View.MeasureSpec.getMode(j1);
        l1 = android.view.View.MeasureSpec.getSize(i1);
        j2 = android.view.View.MeasureSpec.getSize(j1);
        if (i3 != 0x40000000) goto _L2; else goto _L1
_L1:
        int k1 = l1;
        if (k2 == 0x40000000) goto _L3; else goto _L2
_L2:
        if (!isInEditMode()) goto _L5; else goto _L4
_L4:
        if (i3 != 0x80000000) goto _L7; else goto _L6
_L6:
        k1 = l1;
_L11:
        if (k2 == 0x80000000)
        {
            l1 = j2;
            i2 = k1;
            break MISSING_BLOCK_LABEL_84;
        }
        l1 = i2;
        i2 = k1;
          goto _L8
_L7:
        k1 = l1;
        if (i3 == 0)
        {
            k1 = 300;
        }
        continue; /* Loop/switch isn't completed */
_L8:
        if (k2 == 0) goto _L9; else goto _L3
_L3:
        l1 = j2;
        i2 = k1;
          goto _L9
_L5:
        throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
_L9:
        setMeasuredDimension(i2, l1);
        j2 = getChildCount();
        k1 = 0;
        while (k1 < j2) 
        {
            View view = getChildAt(k1);
            if (view.getVisibility() != 8)
            {
                h h1 = (h)view.getLayoutParams();
                if (f(view))
                {
                    view.measure(android.view.View.MeasureSpec.makeMeasureSpec(i2 - h1.leftMargin - h1.rightMargin, 0x40000000), android.view.View.MeasureSpec.makeMeasureSpec(l1 - h1.topMargin - h1.bottomMargin, 0x40000000));
                } else
                if (g(view))
                {
                    int l2 = e(view) & 7;
                    if ((0 & l2) != 0)
                    {
                        throw new IllegalStateException((new StringBuilder()).append("Child drawer has absolute gravity ").append(b(l2)).append(" but this ").append("DrawerLayout").append(" already has a ").append("drawer view along that edge").toString());
                    }
                    view.measure(getChildMeasureSpec(i1, b + h1.leftMargin + h1.rightMargin, h1.width), getChildMeasureSpec(j1, h1.topMargin + h1.bottomMargin, h1.height));
                } else
                {
                    throw new IllegalStateException((new StringBuilder()).append("Child ").append(view).append(" at index ").append(k1).append(" does not have a valid layout_gravity - must be Gravity.LEFT, ").append("Gravity.RIGHT or Gravity.NO_GRAVITY").toString());
                }
            }
            k1++;
        }
        return;
        if (true) goto _L11; else goto _L10
_L10:
    }

    protected void onRestoreInstanceState(Parcelable parcelable)
    {
        parcelable = (SavedState)parcelable;
        super.onRestoreInstanceState(parcelable.getSuperState());
        if (((SavedState) (parcelable)).a != 0)
        {
            View view = a(((SavedState) (parcelable)).a);
            if (view != null)
            {
                h(view);
            }
        }
        a(((SavedState) (parcelable)).b, 3);
        a(((SavedState) (parcelable)).c, 5);
    }

    protected Parcelable onSaveInstanceState()
    {
        SavedState savedstate;
        int i1;
        int j1;
        savedstate = new SavedState(super.onSaveInstanceState());
        j1 = getChildCount();
        i1 = 0;
_L2:
        Object obj;
        if (i1 >= j1)
        {
            break MISSING_BLOCK_LABEL_70;
        }
        obj = getChildAt(i1);
        if (g(((View) (obj))))
        {
            break; /* Loop/switch isn't completed */
        }
_L4:
        i1++;
        if (true) goto _L2; else goto _L1
_L1:
        if (!((h) (obj = (h)((View) (obj)).getLayoutParams())).d) goto _L4; else goto _L3
_L3:
        savedstate.a = ((h) (obj)).a;
        savedstate.b = m;
        savedstate.c = n;
        return savedstate;
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        f.b(motionevent);
        g.b(motionevent);
        motionevent.getAction() & 0xff;
        JVM INSTR tableswitch 0 3: default 56
    //                   0 58
    //                   1 90
    //                   2 56
    //                   3 204;
           goto _L1 _L2 _L3 _L1 _L4
_L1:
        return true;
_L2:
        float f1 = motionevent.getX();
        float f3 = motionevent.getY();
        r = f1;
        s = f3;
        o = false;
        p = false;
        return true;
_L3:
        float f2;
        float f4;
        f4 = motionevent.getX();
        f2 = motionevent.getY();
        motionevent = f.d((int)f4, (int)f2);
        if (motionevent == null || !f(motionevent)) goto _L6; else goto _L5
_L5:
        int i1;
        f4 -= r;
        f2 -= s;
        i1 = f.d();
        if (f4 * f4 + f2 * f2 >= (float)(i1 * i1)) goto _L6; else goto _L7
_L7:
        motionevent = a();
        if (motionevent == null) goto _L6; else goto _L8
_L8:
        boolean flag;
        if (a(motionevent) == 2)
        {
            flag = true;
        } else
        {
            flag = false;
        }
_L10:
        a(flag);
        o = false;
        return true;
_L4:
        a(true);
        o = false;
        p = false;
        return true;
_L6:
        flag = true;
        if (true) goto _L10; else goto _L9
_L9:
    }

    public void requestDisallowInterceptTouchEvent(boolean flag)
    {
        super.requestDisallowInterceptTouchEvent(flag);
        o = flag;
        if (flag)
        {
            a(true);
        }
    }

    public void requestLayout()
    {
        if (!k)
        {
            super.requestLayout();
        }
    }

    public void setDrawerListener(g g1)
    {
        q = g1;
    }

    public void setDrawerLockMode(int i1)
    {
        a(i1, 3);
        a(i1, 5);
    }

    public void setScrimColor(int i1)
    {
        c = i1;
        invalidate();
    }


    private class SavedState extends android.view.View.BaseSavedState
    {

        public static final android.os.Parcelable.Creator CREATOR = new i();
        int a;
        int b;
        int c;

        public void writeToParcel(Parcel parcel, int i1)
        {
            super.writeToParcel(parcel, i1);
            parcel.writeInt(a);
        }


        public SavedState(Parcel parcel)
        {
            super(parcel);
            a = 0;
            b = 0;
            c = 0;
            a = parcel.readInt();
        }

        public SavedState(Parcelable parcelable)
        {
            super(parcelable);
            a = 0;
            b = 0;
            c = 0;
        }
    }

}
