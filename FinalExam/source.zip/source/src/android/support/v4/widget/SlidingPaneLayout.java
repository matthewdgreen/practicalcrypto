// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.support.v4.view.aj;
import android.support.v4.view.au;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

// Referenced classes of package android.support.v4.widget:
//            ae, ad, ac, y, 
//            x, ab, af, z

public class SlidingPaneLayout extends ViewGroup
{

    static final ab a;
    private int b;
    private int c;
    private Drawable d;
    private final int e;
    private boolean f;
    private View g;
    private float h;
    private float i;
    private int j;
    private boolean k;
    private int l;
    private float m;
    private float n;
    private z o;
    private final af p;
    private boolean q;
    private boolean r;
    private final Rect s;
    private final ArrayList t;

    static ArrayList a(SlidingPaneLayout slidingpanelayout)
    {
        return slidingpanelayout.t;
    }

    private void a(float f1)
    {
        int i1 = 0;
        y y1 = (y)g.getLayoutParams();
        boolean flag;
        int j1;
        if (y1.c && y1.leftMargin <= 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        j1 = getChildCount();
        while (i1 < j1) 
        {
            View view = getChildAt(i1);
            if (view != g)
            {
                int k1 = (int)((1.0F - i) * (float)l);
                i = f1;
                view.offsetLeftAndRight(k1 - (int)((1.0F - f1) * (float)l));
                if (flag)
                {
                    a(view, 1.0F - i, c);
                }
            }
            i1++;
        }
    }

    static void a(SlidingPaneLayout slidingpanelayout, View view)
    {
        slidingpanelayout.d(view);
    }

    private void a(View view, float f1, int i1)
    {
        y y1 = (y)view.getLayoutParams();
        if (f1 > 0.0F && i1 != 0)
        {
            int j1 = (int)((float)((0xff000000 & i1) >>> 24) * f1);
            if (y1.d == null)
            {
                y1.d = new Paint();
            }
            y1.d.setColorFilter(new PorterDuffColorFilter(j1 << 24 | 0xffffff & i1, android.graphics.PorterDuff.Mode.SRC_OVER));
            if (au.d(view) != 2)
            {
                au.a(view, 2, y1.d);
            }
            d(view);
        } else
        if (au.d(view) != 0)
        {
            if (y1.d != null)
            {
                y1.d.setColorFilter(null);
            }
            view = new x(this, view);
            t.add(view);
            au.a(this, view);
            return;
        }
    }

    private boolean a(View view, int i1)
    {
        boolean flag = false;
        if (r || a(0.0F, i1))
        {
            q = false;
            flag = true;
        }
        return flag;
    }

    private boolean b(View view, int i1)
    {
        if (r || a(1.0F, i1))
        {
            q = true;
            return true;
        } else
        {
            return false;
        }
    }

    private static boolean c(View view)
    {
        if (!au.f(view))
        {
            if (android.os.Build.VERSION.SDK_INT >= 18)
            {
                return false;
            }
            view = view.getBackground();
            if (view != null)
            {
                if (view.getOpacity() != -1)
                {
                    return false;
                }
            } else
            {
                return false;
            }
        }
        return true;
    }

    private void d(View view)
    {
        a.a(this, view);
    }

    void a()
    {
        int j1 = getChildCount();
        for (int i1 = 0; i1 < j1; i1++)
        {
            View view = getChildAt(i1);
            if (view.getVisibility() == 4)
            {
                view.setVisibility(0);
            }
        }

    }

    void a(View view)
    {
        int k2 = getPaddingLeft();
        int l2 = getWidth();
        int i3 = getPaddingRight();
        int j3 = getPaddingTop();
        int k3 = getHeight();
        int l3 = getPaddingBottom();
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int i4;
        if (view != null && c(view))
        {
            l1 = view.getLeft();
            k1 = view.getRight();
            j1 = view.getTop();
            i1 = view.getBottom();
        } else
        {
            i1 = 0;
            j1 = 0;
            k1 = 0;
            l1 = 0;
        }
        i4 = getChildCount();
        i2 = 0;
        do
        {
            View view1;
label0:
            {
                if (i2 < i4)
                {
                    view1 = getChildAt(i2);
                    if (view1 != view)
                    {
                        break label0;
                    }
                }
                return;
            }
            int j2 = Math.max(k2, view1.getLeft());
            int j4 = Math.max(j3, view1.getTop());
            int k4 = Math.min(l2 - i3, view1.getRight());
            int l4 = Math.min(k3 - l3, view1.getBottom());
            if (j2 >= l1 && j4 >= j1 && k4 <= k1 && l4 <= i1)
            {
                j2 = 4;
            } else
            {
                j2 = 0;
            }
            view1.setVisibility(j2);
            i2++;
        } while (true);
    }

    boolean a(float f1, int i1)
    {
        if (!f)
        {
            return false;
        }
        y y1 = (y)g.getLayoutParams();
        i1 = getPaddingLeft();
        i1 = (int)((float)(y1.leftMargin + i1) + (float)j * f1);
        if (p.a(g, i1, g.getTop()))
        {
            a();
            au.b(this);
            return true;
        } else
        {
            return false;
        }
    }

    public boolean b()
    {
        return b(g, 0);
    }

    boolean b(View view)
    {
        if (view == null)
        {
            return false;
        }
        view = (y)view.getLayoutParams();
        boolean flag;
        if (f && ((y) (view)).c && h > 0.0F)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        return flag;
    }

    public boolean c()
    {
        return a(g, 0);
    }

    protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutparams)
    {
        return (layoutparams instanceof y) && super.checkLayoutParams(layoutparams);
    }

    public void computeScroll()
    {
label0:
        {
            if (p.a(true))
            {
                if (f)
                {
                    break label0;
                }
                p.f();
            }
            return;
        }
        au.b(this);
    }

    public boolean d()
    {
        return !f || h == 1.0F;
    }

    public void draw(Canvas canvas)
    {
        super.draw(canvas);
        View view;
        if (getChildCount() > 1)
        {
            view = getChildAt(1);
        } else
        {
            view = null;
        }
        if (view == null || d == null)
        {
            return;
        } else
        {
            int i1 = d.getIntrinsicWidth();
            int j1 = view.getLeft();
            int k1 = view.getTop();
            int l1 = view.getBottom();
            d.setBounds(j1 - i1, k1, j1, l1);
            d.draw(canvas);
            return;
        }
    }

    protected boolean drawChild(Canvas canvas, View view, long l1)
    {
        y y1 = (y)view.getLayoutParams();
        int i1 = canvas.save(2);
        if (f && !y1.b && g != null)
        {
            canvas.getClipBounds(s);
            s.right = Math.min(s.right, g.getLeft());
            canvas.clipRect(s);
        }
        boolean flag;
        if (android.os.Build.VERSION.SDK_INT >= 11)
        {
            flag = super.drawChild(canvas, view, l1);
        } else
        if (y1.c && h > 0.0F)
        {
            if (!view.isDrawingCacheEnabled())
            {
                view.setDrawingCacheEnabled(true);
            }
            android.graphics.Bitmap bitmap = view.getDrawingCache();
            if (bitmap != null)
            {
                canvas.drawBitmap(bitmap, view.getLeft(), view.getTop(), y1.d);
                flag = false;
            } else
            {
                Log.e("SlidingPaneLayout", (new StringBuilder()).append("drawChild: child view ").append(view).append(" returned null drawing cache").toString());
                flag = super.drawChild(canvas, view, l1);
            }
        } else
        {
            if (view.isDrawingCacheEnabled())
            {
                view.setDrawingCacheEnabled(false);
            }
            flag = super.drawChild(canvas, view, l1);
        }
        canvas.restoreToCount(i1);
        return flag;
    }

    public boolean e()
    {
        return f;
    }

    protected android.view.ViewGroup.LayoutParams generateDefaultLayoutParams()
    {
        return new y();
    }

    public android.view.ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeset)
    {
        return new y(getContext(), attributeset);
    }

    protected android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutparams)
    {
        if (layoutparams instanceof android.view.ViewGroup.MarginLayoutParams)
        {
            return new y((android.view.ViewGroup.MarginLayoutParams)layoutparams);
        } else
        {
            return new y(layoutparams);
        }
    }

    public int getCoveredFadeColor()
    {
        return c;
    }

    public int getParallaxDistance()
    {
        return l;
    }

    public int getSliderFadeColor()
    {
        return b;
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        r = true;
    }

    protected void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        r = true;
        int j1 = t.size();
        for (int i1 = 0; i1 < j1; i1++)
        {
            ((x)t.get(i1)).run();
        }

        t.clear();
    }

    public boolean onInterceptTouchEvent(MotionEvent motionevent)
    {
        int i1;
        boolean flag;
        boolean flag1;
        flag1 = false;
        i1 = aj.a(motionevent);
        if (!f && i1 == 0 && getChildCount() > 1)
        {
            View view = getChildAt(1);
            if (view != null)
            {
                if (!p.b(view, (int)motionevent.getX(), (int)motionevent.getY()))
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                q = flag;
            }
        }
        if (f && (!k || i1 == 0)) goto _L2; else goto _L1
_L1:
        p.e();
        flag = super.onInterceptTouchEvent(motionevent);
_L7:
        return flag;
_L2:
        if (i1 == 3 || i1 == 1)
        {
            p.e();
            return false;
        }
        i1;
        JVM INSTR tableswitch 0 2: default 164
    //                   0 189
    //                   1 164
    //                   2 249;
           goto _L3 _L4 _L3 _L5
_L3:
        i1 = 0;
_L9:
        if (p.a(motionevent))
        {
            break; /* Loop/switch isn't completed */
        }
        flag = flag1;
        if (!i1) goto _L7; else goto _L6
_L6:
        return true;
_L4:
        float f1;
        float f3;
        k = false;
        f1 = motionevent.getX();
        f3 = motionevent.getY();
        m = f1;
        n = f3;
        if (!p.b(g, (int)f1, (int)f3) || !b(g)) goto _L3; else goto _L8
_L8:
        i1 = 1;
          goto _L9
_L5:
        float f4 = motionevent.getX();
        float f2 = motionevent.getY();
        f4 = Math.abs(f4 - m);
        f2 = Math.abs(f2 - n);
        if (f4 > (float)p.d() && f2 > f4)
        {
            p.e();
            k = true;
            return false;
        }
          goto _L3
    }

    protected void onLayout(boolean flag, int i1, int j1, int k1, int l1)
    {
        int j2 = k1 - i1;
        i1 = getPaddingLeft();
        int k2 = getPaddingRight();
        int l2 = getPaddingTop();
        int i2 = getChildCount();
        if (r)
        {
            float f1;
            if (f && q)
            {
                f1 = 1.0F;
            } else
            {
                f1 = 0.0F;
            }
            h = f1;
        }
        l1 = 0;
        j1 = i1;
        while (l1 < i2) 
        {
            View view = getChildAt(l1);
            if (view.getVisibility() != 8)
            {
                y y1 = (y)view.getLayoutParams();
                int i3 = view.getMeasuredWidth();
                if (y1.b)
                {
                    k1 = y1.leftMargin;
                    int j3 = y1.rightMargin;
                    k1 = Math.min(i1, j2 - k2 - e) - j1 - (k1 + j3);
                    j = k1;
                    if (y1.leftMargin + j1 + k1 + i3 / 2 > j2 - k2)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    y1.c = flag;
                    k1 = (int)((float)k1 * h);
                    j1 = y1.leftMargin + k1 + j1;
                    k1 = 0;
                } else
                if (f && l != 0)
                {
                    k1 = (int)((1.0F - h) * (float)l);
                    j1 = i1;
                } else
                {
                    k1 = 0;
                    j1 = i1;
                }
                k1 = j1 - k1;
                view.layout(k1, l2, k1 + i3, view.getMeasuredHeight() + l2);
                i1 += view.getWidth();
            }
            l1++;
        }
        if (r)
        {
            if (f)
            {
                if (l != 0)
                {
                    a(h);
                }
                if (((y)g.getLayoutParams()).c)
                {
                    a(g, h, b);
                }
            } else
            {
                i1 = 0;
                while (i1 < i2) 
                {
                    a(getChildAt(i1), 0.0F, b);
                    i1++;
                }
            }
            a(g);
        }
        r = false;
    }

    protected void onMeasure(int i1, int j1)
    {
        int k1;
        int l1;
        int i2;
        i2 = android.view.View.MeasureSpec.getMode(i1);
        k1 = android.view.View.MeasureSpec.getSize(i1);
        l1 = android.view.View.MeasureSpec.getMode(j1);
        i1 = android.view.View.MeasureSpec.getSize(j1);
        if (i2 == 0x40000000) goto _L2; else goto _L1
_L1:
        if (!isInEditMode()) goto _L4; else goto _L3
_L3:
        if (i2 != 0x80000000) goto _L6; else goto _L5
_L5:
        j1 = k1;
        k1 = l1;
_L16:
        k1;
        JVM INSTR lookupswitch 2: default 80
    //                   -2147483648: 295
    //                   1073741824: 277;
           goto _L7 _L8 _L9
_L7:
        i1 = 0;
        i2 = -1;
_L13:
        float f1;
        int i4;
        int k4;
        boolean flag;
        flag = false;
        l1 = j1 - getPaddingLeft() - getPaddingRight();
        k4 = getChildCount();
        if (k4 > 2)
        {
            Log.e("SlidingPaneLayout", "onMeasure: More than two child views are not supported.");
        }
        g = null;
        i4 = 0;
        f1 = 0.0F;
_L11:
        float f2;
        View view;
        y y1;
        if (i4 >= k4)
        {
            break; /* Loop/switch isn't completed */
        }
        view = getChildAt(i4);
        y1 = (y)view.getLayoutParams();
        int k2;
        if (view.getVisibility() == 8)
        {
            y1.c = false;
            int j2 = l1;
            l1 = i1;
            i1 = j2;
        } else
        {
label0:
            {
                f2 = f1;
                if (y1.a <= 0.0F)
                {
                    break label0;
                }
                f1 += y1.a;
                f2 = f1;
                if (y1.width != 0)
                {
                    break label0;
                }
                int l2 = i1;
                i1 = l1;
                l1 = l2;
            }
        }
_L14:
        i4++;
        k2 = l1;
        l1 = i1;
        i1 = k2;
        if (true) goto _L11; else goto _L10
_L6:
        if (i2 == 0)
        {
            k1 = l1;
            j1 = 300;
            continue; /* Loop/switch isn't completed */
        }
          goto _L12
_L4:
        throw new IllegalStateException("Width must have an exact value or MATCH_PARENT");
_L2:
        if (l1 == 0)
        {
            if (isInEditMode())
            {
                if (l1 == 0)
                {
                    l1 = 0x80000000;
                    j1 = k1;
                    i1 = 300;
                    k1 = l1;
                    continue; /* Loop/switch isn't completed */
                }
            } else
            {
                throw new IllegalStateException("Height must not be UNSPECIFIED");
            }
        }
          goto _L12
_L9:
        i1 = i1 - getPaddingTop() - getPaddingBottom();
        i2 = i1;
          goto _L13
_L8:
        i2 = getPaddingTop();
        k2 = getPaddingBottom();
        l1 = 0;
        i2 = i1 - i2 - k2;
        i1 = l1;
          goto _L13
        int i3 = y1.leftMargin + y1.rightMargin;
        int k3;
        int l4;
        boolean flag1;
        if (y1.width == -2)
        {
            i3 = android.view.View.MeasureSpec.makeMeasureSpec(j1 - i3, 0x80000000);
        } else
        if (y1.width == -1)
        {
            i3 = android.view.View.MeasureSpec.makeMeasureSpec(j1 - i3, 0x40000000);
        } else
        {
            i3 = android.view.View.MeasureSpec.makeMeasureSpec(y1.width, 0x40000000);
        }
        if (y1.height == -2)
        {
            k3 = android.view.View.MeasureSpec.makeMeasureSpec(i2, 0x80000000);
        } else
        if (y1.height == -1)
        {
            k3 = android.view.View.MeasureSpec.makeMeasureSpec(i2, 0x40000000);
        } else
        {
            k3 = android.view.View.MeasureSpec.makeMeasureSpec(y1.height, 0x40000000);
        }
        view.measure(i3, k3);
        k3 = view.getMeasuredWidth();
        l4 = view.getMeasuredHeight();
        i3 = i1;
        if (k1 == 0x80000000)
        {
            i3 = i1;
            if (l4 > i1)
            {
                i3 = Math.min(l4, i2);
            }
        }
        i1 = l1 - k3;
        if (i1 < 0)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        y1.b = flag1;
        if (y1.b)
        {
            g = view;
        }
        l1 = i3;
        flag = flag1 | flag;
        f1 = f2;
          goto _L14
_L10:
        if (flag || f1 > 0.0F)
        {
            int j4 = j1 - e;
            int j3 = 0;
            while (j3 < k4) 
            {
                View view1 = getChildAt(j3);
                if (view1.getVisibility() != 8)
                {
                    y y2 = (y)view1.getLayoutParams();
                    if (view1.getVisibility() != 8)
                    {
                        int l3;
                        if (y2.width == 0 && y2.a > 0.0F)
                        {
                            k1 = 1;
                        } else
                        {
                            k1 = 0;
                        }
                        if (k1 != 0)
                        {
                            l3 = 0;
                        } else
                        {
                            l3 = view1.getMeasuredWidth();
                        }
                        if (flag && view1 != g)
                        {
                            if (y2.width < 0 && (l3 > j4 || y2.a > 0.0F))
                            {
                                if (k1 != 0)
                                {
                                    if (y2.height == -2)
                                    {
                                        k1 = android.view.View.MeasureSpec.makeMeasureSpec(i2, 0x80000000);
                                    } else
                                    if (y2.height == -1)
                                    {
                                        k1 = android.view.View.MeasureSpec.makeMeasureSpec(i2, 0x40000000);
                                    } else
                                    {
                                        k1 = android.view.View.MeasureSpec.makeMeasureSpec(y2.height, 0x40000000);
                                    }
                                } else
                                {
                                    k1 = android.view.View.MeasureSpec.makeMeasureSpec(view1.getMeasuredHeight(), 0x40000000);
                                }
                                view1.measure(android.view.View.MeasureSpec.makeMeasureSpec(j4, 0x40000000), k1);
                            }
                        } else
                        if (y2.a > 0.0F)
                        {
                            if (y2.width == 0)
                            {
                                if (y2.height == -2)
                                {
                                    k1 = android.view.View.MeasureSpec.makeMeasureSpec(i2, 0x80000000);
                                } else
                                if (y2.height == -1)
                                {
                                    k1 = android.view.View.MeasureSpec.makeMeasureSpec(i2, 0x40000000);
                                } else
                                {
                                    k1 = android.view.View.MeasureSpec.makeMeasureSpec(y2.height, 0x40000000);
                                }
                            } else
                            {
                                k1 = android.view.View.MeasureSpec.makeMeasureSpec(view1.getMeasuredHeight(), 0x40000000);
                            }
                            if (flag)
                            {
                                int i5 = y2.leftMargin;
                                i5 = j1 - (y2.rightMargin + i5);
                                int k5 = android.view.View.MeasureSpec.makeMeasureSpec(i5, 0x40000000);
                                if (l3 != i5)
                                {
                                    view1.measure(k5, k1);
                                }
                            } else
                            {
                                int j5 = Math.max(0, l1);
                                view1.measure(android.view.View.MeasureSpec.makeMeasureSpec((int)((y2.a * (float)j5) / f1) + l3, 0x40000000), k1);
                            }
                        }
                    }
                }
                j3++;
            }
        }
        setMeasuredDimension(j1, i1);
        f = flag;
        if (p.a() != 0 && !flag)
        {
            p.f();
        }
        return;
_L12:
        j1 = k1;
        k1 = l1;
        if (true) goto _L16; else goto _L15
_L15:
    }

    protected void onRestoreInstanceState(Parcelable parcelable)
    {
        parcelable = (SavedState)parcelable;
        super.onRestoreInstanceState(parcelable.getSuperState());
        if (((SavedState) (parcelable)).a)
        {
            b();
        } else
        {
            c();
        }
        q = ((SavedState) (parcelable)).a;
    }

    protected Parcelable onSaveInstanceState()
    {
        SavedState savedstate = new SavedState(super.onSaveInstanceState());
        boolean flag;
        if (e())
        {
            flag = d();
        } else
        {
            flag = q;
        }
        savedstate.a = flag;
        return savedstate;
    }

    protected void onSizeChanged(int i1, int j1, int k1, int l1)
    {
        super.onSizeChanged(i1, j1, k1, l1);
        if (i1 != k1)
        {
            r = true;
        }
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        boolean flag;
        if (!f)
        {
            flag = super.onTouchEvent(motionevent);
        } else
        {
            p.b(motionevent);
            int i1 = motionevent.getAction();
            boolean flag1 = true;
            switch (i1 & 0xff)
            {
            default:
                return true;

            case 0: // '\0'
                float f1 = motionevent.getX();
                float f3 = motionevent.getY();
                m = f1;
                n = f3;
                return true;

            case 1: // '\001'
                flag = flag1;
                break;
            }
            if (b(g))
            {
                float f2 = motionevent.getX();
                float f4 = motionevent.getY();
                float f5 = f2 - m;
                float f6 = f4 - n;
                int j1 = p.d();
                flag = flag1;
                if (f5 * f5 + f6 * f6 < (float)(j1 * j1))
                {
                    flag = flag1;
                    if (p.b(g, (int)f2, (int)f4))
                    {
                        a(g, 0);
                        return true;
                    }
                }
            }
        }
        return flag;
    }

    public void requestChildFocus(View view, View view1)
    {
        super.requestChildFocus(view, view1);
        if (!isInTouchMode() && !f)
        {
            boolean flag;
            if (view == g)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            q = flag;
        }
    }

    public void setCoveredFadeColor(int i1)
    {
        c = i1;
    }

    public void setPanelSlideListener(z z)
    {
        o = z;
    }

    public void setParallaxDistance(int i1)
    {
        l = i1;
        requestLayout();
    }

    public void setShadowDrawable(Drawable drawable)
    {
        d = drawable;
    }

    public void setShadowResource(int i1)
    {
        setShadowDrawable(getResources().getDrawable(i1));
    }

    public void setSliderFadeColor(int i1)
    {
        b = i1;
    }

    static 
    {
        int i1 = android.os.Build.VERSION.SDK_INT;
        if (i1 >= 17)
        {
            a = new ae();
        } else
        if (i1 >= 16)
        {
            a = new ad();
        } else
        {
            a = new ac();
        }
    }

    private class SavedState extends android.view.View.BaseSavedState
    {

        public static final android.os.Parcelable.Creator CREATOR = new aa();
        boolean a;

        public void writeToParcel(Parcel parcel, int i1)
        {
            super.writeToParcel(parcel, i1);
            if (a)
            {
                i1 = 1;
            } else
            {
                i1 = 0;
            }
            parcel.writeInt(i1);
        }


        private SavedState(Parcel parcel)
        {
            super(parcel);
            boolean flag;
            if (parcel.readInt() != 0)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            a = flag;
        }

        SavedState(Parcel parcel, w w)
        {
            this(parcel);
        }

        SavedState(Parcelable parcelable)
        {
            super(parcelable);
        }
    }

}
