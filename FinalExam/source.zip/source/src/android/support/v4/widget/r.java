// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;


interface r
{

    public abstract void a(Object obj, int i, int j, int k, int l, int i1);

    public abstract boolean a(Object obj);

    public abstract int b(Object obj);

    public abstract int c(Object obj);

    public abstract boolean d(Object obj);

    public abstract void e(Object obj);

    public abstract int f(Object obj);

    public abstract int g(Object obj);
}
