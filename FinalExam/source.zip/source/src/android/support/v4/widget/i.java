// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.os.Parcel;

final class i
    implements android.os.Parcelable.Creator
{

    i()
    {
    }

    public DrawerLayout.SavedState a(Parcel parcel)
    {
        return new DrawerLayout.SavedState(parcel);
    }

    public DrawerLayout.SavedState[] a(int j)
    {
        return new DrawerLayout.SavedState[j];
    }

    public Object createFromParcel(Parcel parcel)
    {
        return a(parcel);
    }

    public Object[] newArray(int j)
    {
        return a(j);
    }
}
