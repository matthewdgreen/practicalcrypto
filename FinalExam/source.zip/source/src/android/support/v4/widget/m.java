// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;

// Referenced classes of package android.support.v4.widget:
//            n, o

class m
    implements n
{

    m()
    {
    }

    public Object a(Context context)
    {
        return o.a(context);
    }

    public void a(Object obj, int i, int j)
    {
        o.a(obj, i, j);
    }

    public boolean a(Object obj)
    {
        return o.a(obj);
    }

    public boolean a(Object obj, float f)
    {
        return o.a(obj, f);
    }

    public boolean a(Object obj, Canvas canvas)
    {
        return o.a(obj, canvas);
    }

    public void b(Object obj)
    {
        o.b(obj);
    }

    public boolean c(Object obj)
    {
        return o.c(obj);
    }
}
