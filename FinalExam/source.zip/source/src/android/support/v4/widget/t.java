// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;


// Referenced classes of package android.support.v4.widget:
//            r, v

class t
    implements r
{

    t()
    {
    }

    public void a(Object obj, int i, int j, int k, int l, int i1)
    {
        v.a(obj, i, j, k, l, i1);
    }

    public boolean a(Object obj)
    {
        return v.a(obj);
    }

    public int b(Object obj)
    {
        return v.b(obj);
    }

    public int c(Object obj)
    {
        return v.c(obj);
    }

    public boolean d(Object obj)
    {
        return v.d(obj);
    }

    public void e(Object obj)
    {
        v.e(obj);
    }

    public int f(Object obj)
    {
        return v.f(obj);
    }

    public int g(Object obj)
    {
        return v.g(obj);
    }
}
