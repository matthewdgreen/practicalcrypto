// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;


public interface bw
{

    public abstract void a(int i);

    public abstract void a(int i, float f, int j);

    public abstract void b(int i);
}
