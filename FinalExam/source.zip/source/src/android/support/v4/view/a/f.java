// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;

import android.graphics.Rect;

// Referenced classes of package android.support.v4.view.a:
//            c

class f
    implements c
{

    f()
    {
    }

    public int a(Object obj)
    {
        return 0;
    }

    public void a(Object obj, int i1)
    {
    }

    public void a(Object obj, Rect rect)
    {
    }

    public void a(Object obj, CharSequence charsequence)
    {
    }

    public void a(Object obj, boolean flag)
    {
    }

    public CharSequence b(Object obj)
    {
        return null;
    }

    public void b(Object obj, Rect rect)
    {
    }

    public CharSequence c(Object obj)
    {
        return null;
    }

    public CharSequence d(Object obj)
    {
        return null;
    }

    public CharSequence e(Object obj)
    {
        return null;
    }

    public boolean f(Object obj)
    {
        return false;
    }

    public boolean g(Object obj)
    {
        return false;
    }

    public boolean h(Object obj)
    {
        return false;
    }

    public boolean i(Object obj)
    {
        return false;
    }

    public boolean j(Object obj)
    {
        return false;
    }

    public boolean k(Object obj)
    {
        return false;
    }

    public boolean l(Object obj)
    {
        return false;
    }

    public boolean m(Object obj)
    {
        return false;
    }

    public boolean n(Object obj)
    {
        return false;
    }

    public boolean o(Object obj)
    {
        return false;
    }

    public String p(Object obj)
    {
        return null;
    }
}
