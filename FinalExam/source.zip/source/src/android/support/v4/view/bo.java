// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import java.util.Comparator;

// Referenced classes of package android.support.v4.view:
//            bs

final class bo
    implements Comparator
{

    bo()
    {
    }

    public int a(bs bs1, bs bs2)
    {
        return bs1.b - bs2.b;
    }

    public int compare(Object obj, Object obj1)
    {
        return a((bs)obj, (bs)obj1);
    }
}
