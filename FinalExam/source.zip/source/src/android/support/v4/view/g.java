// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.os.Bundle;
import android.support.v4.view.a.a;
import android.support.v4.view.a.i;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

// Referenced classes of package android.support.v4.view:
//            d, a

class g
    implements d
{

    g()
    {
    }

    public i a(Object obj, View view)
    {
        return null;
    }

    public Object a()
    {
        return null;
    }

    public Object a(android.support.v4.view.a a1)
    {
        return null;
    }

    public void a(Object obj, View view, int i)
    {
    }

    public void a(Object obj, View view, a a1)
    {
    }

    public boolean a(Object obj, View view, int i, Bundle bundle)
    {
        return false;
    }

    public boolean a(Object obj, View view, AccessibilityEvent accessibilityevent)
    {
        return false;
    }

    public boolean a(Object obj, ViewGroup viewgroup, View view, AccessibilityEvent accessibilityevent)
    {
        return true;
    }

    public void b(Object obj, View view, AccessibilityEvent accessibilityevent)
    {
    }

    public void c(Object obj, View view, AccessibilityEvent accessibilityevent)
    {
    }

    public void d(Object obj, View view, AccessibilityEvent accessibilityevent)
    {
    }
}
