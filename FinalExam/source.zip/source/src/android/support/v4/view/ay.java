// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

// Referenced classes of package android.support.v4.view:
//            ax, bf

class ay extends ax
{

    ay()
    {
    }

    long a()
    {
        return bf.a();
    }

    public void a(View view, int i, Paint paint)
    {
        bf.a(view, i, paint);
    }

    public void a(View view, Paint paint)
    {
        a(view, d(view), paint);
        view.invalidate();
    }

    public int d(View view)
    {
        return bf.a(view);
    }
}
