// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;


// Referenced classes of package android.support.v4.view:
//            x, ab

class y extends x
{

    y()
    {
    }

    public int a(int i)
    {
        return ab.a(i);
    }

    public boolean a(int i, int j)
    {
        return ab.a(i, j);
    }

    public boolean b(int i)
    {
        return ab.b(i);
    }
}
