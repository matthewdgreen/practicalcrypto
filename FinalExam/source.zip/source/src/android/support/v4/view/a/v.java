// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;


// Referenced classes of package android.support.v4.view.a:
//            t

class v
    implements t
{

    v()
    {
    }

    public Object a()
    {
        return null;
    }

    public void a(Object obj, int i)
    {
    }

    public void a(Object obj, boolean flag)
    {
    }

    public void b(Object obj, int i)
    {
    }

    public void c(Object obj, int i)
    {
    }
}
