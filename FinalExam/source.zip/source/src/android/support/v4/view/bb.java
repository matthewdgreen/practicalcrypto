// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

// Referenced classes of package android.support.v4.view:
//            ba, bi

class bb extends ba
{

    bb()
    {
    }

    public void a(View view, Paint paint)
    {
        bi.a(view, paint);
    }

    public int e(View view)
    {
        return bi.a(view);
    }
}
