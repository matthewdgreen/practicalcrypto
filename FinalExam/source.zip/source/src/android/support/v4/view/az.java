// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.View;

// Referenced classes of package android.support.v4.view:
//            ay, a, bg

class az extends ay
{

    az()
    {
    }

    public void a(View view, a a1)
    {
        bg.a(view, a1.a());
    }

    public boolean a(View view, int i)
    {
        return bg.a(view, i);
    }
}
