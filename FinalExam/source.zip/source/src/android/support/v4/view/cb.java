// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.View;
import java.util.Comparator;

// Referenced classes of package android.support.v4.view:
//            bt

class cb
    implements Comparator
{

    cb()
    {
    }

    public int a(View view, View view1)
    {
        view = (bt)view.getLayoutParams();
        view1 = (bt)view1.getLayoutParams();
        if (((bt) (view)).a != ((bt) (view1)).a)
        {
            return !((bt) (view)).a ? -1 : 1;
        } else
        {
            return ((bt) (view)).e - ((bt) (view1)).e;
        }
    }

    public int compare(Object obj, Object obj1)
    {
        return a((View)obj, (View)obj1);
    }
}
