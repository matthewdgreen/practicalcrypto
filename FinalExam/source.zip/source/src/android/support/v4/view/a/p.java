// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;

import android.os.Bundle;
import java.util.List;

interface p
{

    public abstract Object a(int i);

    public abstract List a(String s, int i);

    public abstract boolean a(int i, int j, Bundle bundle);
}
