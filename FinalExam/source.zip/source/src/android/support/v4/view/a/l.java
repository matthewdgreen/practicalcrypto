// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package android.support.v4.view.a:
//            p, i, a, k

class l
    implements p
{

    final i a;
    final k b;

    l(k k, i j)
    {
        b = k;
        a = j;
        super();
    }

    public Object a(int j)
    {
        a a1 = a.a(j);
        if (a1 == null)
        {
            return null;
        } else
        {
            return a1.a();
        }
    }

    public List a(String s, int j)
    {
        s = a.a(s, j);
        ArrayList arraylist = new ArrayList();
        int k = s.size();
        for (j = 0; j < k; j++)
        {
            arraylist.add(((a)s.get(j)).a());
        }

        return arraylist;
    }

    public boolean a(int j, int k, Bundle bundle)
    {
        return a.a(j, k, bundle);
    }
}
