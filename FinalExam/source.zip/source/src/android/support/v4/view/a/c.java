// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;

import android.graphics.Rect;

interface c
{

    public abstract int a(Object obj);

    public abstract void a(Object obj, int i1);

    public abstract void a(Object obj, Rect rect);

    public abstract void a(Object obj, CharSequence charsequence);

    public abstract void a(Object obj, boolean flag);

    public abstract CharSequence b(Object obj);

    public abstract void b(Object obj, Rect rect);

    public abstract CharSequence c(Object obj);

    public abstract CharSequence d(Object obj);

    public abstract CharSequence e(Object obj);

    public abstract boolean f(Object obj);

    public abstract boolean g(Object obj);

    public abstract boolean h(Object obj);

    public abstract boolean i(Object obj);

    public abstract boolean j(Object obj);

    public abstract boolean k(Object obj);

    public abstract boolean l(Object obj);

    public abstract boolean m(Object obj);

    public abstract boolean n(Object obj);

    public abstract boolean o(Object obj);

    public abstract String p(Object obj);
}
