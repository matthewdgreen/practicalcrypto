// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

// Referenced classes of package android.support.v4.view:
//            a

interface bc
{

    public abstract int a(View view);

    public abstract void a(View view, int i, int j, int k, int l);

    public abstract void a(View view, int i, Paint paint);

    public abstract void a(View view, Paint paint);

    public abstract void a(View view, a a1);

    public abstract void a(View view, Runnable runnable);

    public abstract boolean a(View view, int i);

    public abstract void b(View view);

    public abstract void b(View view, int i);

    public abstract int c(View view);

    public abstract int d(View view);

    public abstract int e(View view);

    public abstract boolean f(View view);
}
