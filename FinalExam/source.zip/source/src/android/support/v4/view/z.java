// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.KeyEvent;

interface z
{

    public abstract void a(KeyEvent keyevent);

    public abstract boolean a(int i, int j);

    public abstract boolean b(int i);
}
