// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;

import android.graphics.Rect;

// Referenced classes of package android.support.v4.view.a:
//            f, g

class b extends f
{

    b()
    {
    }

    public int a(Object obj)
    {
        return android.support.v4.view.a.g.a(obj);
    }

    public void a(Object obj, int i1)
    {
        android.support.v4.view.a.g.a(obj, i1);
    }

    public void a(Object obj, Rect rect)
    {
        android.support.v4.view.a.g.a(obj, rect);
    }

    public void a(Object obj, CharSequence charsequence)
    {
        android.support.v4.view.a.g.a(obj, charsequence);
    }

    public void a(Object obj, boolean flag)
    {
        android.support.v4.view.a.g.a(obj, flag);
    }

    public CharSequence b(Object obj)
    {
        return android.support.v4.view.a.g.b(obj);
    }

    public void b(Object obj, Rect rect)
    {
        android.support.v4.view.a.g.b(obj, rect);
    }

    public CharSequence c(Object obj)
    {
        return android.support.v4.view.a.g.c(obj);
    }

    public CharSequence d(Object obj)
    {
        return android.support.v4.view.a.g.d(obj);
    }

    public CharSequence e(Object obj)
    {
        return android.support.v4.view.a.g.e(obj);
    }

    public boolean f(Object obj)
    {
        return android.support.v4.view.a.g.f(obj);
    }

    public boolean g(Object obj)
    {
        return android.support.v4.view.a.g.g(obj);
    }

    public boolean h(Object obj)
    {
        return android.support.v4.view.a.g.h(obj);
    }

    public boolean i(Object obj)
    {
        return android.support.v4.view.a.g.i(obj);
    }

    public boolean j(Object obj)
    {
        return android.support.v4.view.a.g.j(obj);
    }

    public boolean k(Object obj)
    {
        return android.support.v4.view.a.g.k(obj);
    }

    public boolean l(Object obj)
    {
        return android.support.v4.view.a.g.l(obj);
    }

    public boolean m(Object obj)
    {
        return android.support.v4.view.a.g.m(obj);
    }

    public boolean n(Object obj)
    {
        return android.support.v4.view.a.g.n(obj);
    }

    public boolean o(Object obj)
    {
        return android.support.v4.view.a.g.o(obj);
    }
}
