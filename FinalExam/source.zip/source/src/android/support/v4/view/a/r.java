// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;


// Referenced classes of package android.support.v4.view.a:
//            v, w

class r extends v
{

    r()
    {
    }

    public Object a()
    {
        return w.a();
    }

    public void a(Object obj, int i)
    {
        w.a(obj, i);
    }

    public void a(Object obj, boolean flag)
    {
        w.a(obj, flag);
    }

    public void b(Object obj, int i)
    {
        w.b(obj, i);
    }

    public void c(Object obj, int i)
    {
        w.c(obj, i);
    }
}
