// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;

import android.os.Bundle;
import java.util.List;

// Referenced classes of package android.support.v4.view.a:
//            k, m, j, a

public class i
{

    private static final j a;
    private final Object b;

    public i()
    {
        b = a.a(this);
    }

    public i(Object obj)
    {
        b = obj;
    }

    public a a(int l)
    {
        return null;
    }

    public Object a()
    {
        return b;
    }

    public List a(String s, int l)
    {
        return null;
    }

    public boolean a(int l, int i1, Bundle bundle)
    {
        return false;
    }

    static 
    {
        if (android.os.Build.VERSION.SDK_INT >= 16)
        {
            a = new k();
        } else
        {
            a = new m();
        }
    }
}
