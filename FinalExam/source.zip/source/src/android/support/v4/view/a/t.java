// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.a;


interface t
{

    public abstract Object a();

    public abstract void a(Object obj, int i);

    public abstract void a(Object obj, boolean flag);

    public abstract void b(Object obj, int i);

    public abstract void c(Object obj, int i);
}
