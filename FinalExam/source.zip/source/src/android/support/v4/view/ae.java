// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.MenuItem;
import android.view.View;

// Referenced classes of package android.support.v4.view:
//            ag, ai

class ae
    implements ag
{

    ae()
    {
    }

    public MenuItem a(MenuItem menuitem, View view)
    {
        return ai.a(menuitem, view);
    }

    public void a(MenuItem menuitem, int i)
    {
        ai.a(menuitem, i);
    }

    public MenuItem b(MenuItem menuitem, int i)
    {
        return ai.b(menuitem, i);
    }
}
