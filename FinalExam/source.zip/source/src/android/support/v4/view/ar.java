// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.VelocityTracker;

// Referenced classes of package android.support.v4.view:
//            as, at

class ar
    implements as
{

    ar()
    {
    }

    public float a(VelocityTracker velocitytracker, int i)
    {
        return at.a(velocitytracker, i);
    }

    public float b(VelocityTracker velocitytracker, int i)
    {
        return at.b(velocitytracker, i);
    }
}
