// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.MotionEvent;

// Referenced classes of package android.support.v4.view:
//            am, an

class al
    implements am
{

    al()
    {
    }

    public int a(MotionEvent motionevent)
    {
        return an.a(motionevent);
    }

    public int a(MotionEvent motionevent, int i)
    {
        return an.a(motionevent, i);
    }

    public int b(MotionEvent motionevent, int i)
    {
        return an.b(motionevent, i);
    }

    public float c(MotionEvent motionevent, int i)
    {
        return an.c(motionevent, i);
    }

    public float d(MotionEvent motionevent, int i)
    {
        return an.d(motionevent, i);
    }
}
