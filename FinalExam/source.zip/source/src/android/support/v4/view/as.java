// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.VelocityTracker;

interface as
{

    public abstract float a(VelocityTracker velocitytracker, int i);

    public abstract float b(VelocityTracker velocitytracker, int i);
}
