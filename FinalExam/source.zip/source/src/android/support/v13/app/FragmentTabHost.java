// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v13.app;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Parcelable;
import android.widget.TabHost;
import java.util.ArrayList;

// Referenced classes of package android.support.v13.app:
//            c

public class FragmentTabHost extends TabHost
    implements android.widget.TabHost.OnTabChangeListener
{

    private final ArrayList a;
    private Context b;
    private FragmentManager c;
    private int d;
    private android.widget.TabHost.OnTabChangeListener e;
    private c f;
    private boolean g;

    private FragmentTransaction a(String s, FragmentTransaction fragmenttransaction)
    {
        c c1 = null;
        for (int i = 0; i < a.size(); i++)
        {
            c c2 = (c)a.get(i);
            if (android.support.v13.app.c.b(c2).equals(s))
            {
                c1 = c2;
            }
        }

        if (c1 == null)
        {
            throw new IllegalStateException((new StringBuilder()).append("No tab known for tag ").append(s).toString());
        }
        s = fragmenttransaction;
        if (f != c1)
        {
            s = fragmenttransaction;
            if (fragmenttransaction == null)
            {
                s = c.beginTransaction();
            }
            if (f != null && android.support.v13.app.c.a(f) != null)
            {
                s.detach(android.support.v13.app.c.a(f));
            }
            if (c1 != null)
            {
                if (android.support.v13.app.c.a(c1) == null)
                {
                    android.support.v13.app.c.a(c1, Fragment.instantiate(b, android.support.v13.app.c.c(c1).getName(), android.support.v13.app.c.d(c1)));
                    s.add(d, android.support.v13.app.c.a(c1), android.support.v13.app.c.b(c1));
                } else
                {
                    s.attach(android.support.v13.app.c.a(c1));
                }
            }
            f = c1;
        }
        return s;
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        String s = getCurrentTabTag();
        FragmentTransaction fragmenttransaction = null;
        int i = 0;
        while (i < a.size()) 
        {
            c c1 = (c)a.get(i);
            android.support.v13.app.c.a(c1, c.findFragmentByTag(android.support.v13.app.c.b(c1)));
            FragmentTransaction fragmenttransaction1 = fragmenttransaction;
            if (android.support.v13.app.c.a(c1) != null)
            {
                fragmenttransaction1 = fragmenttransaction;
                if (!android.support.v13.app.c.a(c1).isDetached())
                {
                    if (android.support.v13.app.c.b(c1).equals(s))
                    {
                        f = c1;
                        fragmenttransaction1 = fragmenttransaction;
                    } else
                    {
                        fragmenttransaction1 = fragmenttransaction;
                        if (fragmenttransaction == null)
                        {
                            fragmenttransaction1 = c.beginTransaction();
                        }
                        fragmenttransaction1.detach(android.support.v13.app.c.a(c1));
                    }
                }
            }
            i++;
            fragmenttransaction = fragmenttransaction1;
        }
        g = true;
        fragmenttransaction = a(s, fragmenttransaction);
        if (fragmenttransaction != null)
        {
            fragmenttransaction.commit();
            c.executePendingTransactions();
        }
    }

    protected void onDetachedFromWindow()
    {
        super.onDetachedFromWindow();
        g = false;
    }

    protected void onRestoreInstanceState(Parcelable parcelable)
    {
        parcelable = (SavedState)parcelable;
        super.onRestoreInstanceState(parcelable.getSuperState());
        setCurrentTabByTag(((SavedState) (parcelable)).a);
    }

    protected Parcelable onSaveInstanceState()
    {
        SavedState savedstate = new SavedState(super.onSaveInstanceState());
        savedstate.a = getCurrentTabTag();
        return savedstate;
    }

    public void onTabChanged(String s)
    {
        if (g)
        {
            FragmentTransaction fragmenttransaction = a(s, null);
            if (fragmenttransaction != null)
            {
                fragmenttransaction.commit();
            }
        }
        if (e != null)
        {
            e.onTabChanged(s);
        }
    }

    public void setOnTabChangedListener(android.widget.TabHost.OnTabChangeListener ontabchangelistener)
    {
        e = ontabchangelistener;
    }

    public void setup()
    {
        throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
    }

    private class SavedState extends android.view.View.BaseSavedState
    {

        public static final android.os.Parcelable.Creator CREATOR = new b();
        String a;

        public String toString()
        {
            return (new StringBuilder()).append("FragmentTabHost.SavedState{").append(Integer.toHexString(System.identityHashCode(this))).append(" curTab=").append(a).append("}").toString();
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            super.writeToParcel(parcel, i);
            parcel.writeString(a);
        }


        private SavedState(Parcel parcel)
        {
            super(parcel);
            a = parcel.readString();
        }

        SavedState(Parcel parcel, a a1)
        {
            this(parcel);
        }

        SavedState(Parcelable parcelable)
        {
            super(parcelable);
        }
    }

}
