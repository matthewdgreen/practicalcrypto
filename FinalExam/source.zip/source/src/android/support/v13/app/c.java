// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v13.app;

import android.app.Fragment;
import android.os.Bundle;

final class c
{

    private final String a;
    private final Class b;
    private final Bundle c;
    private Fragment d;

    static Fragment a(c c1)
    {
        return c1.d;
    }

    static Fragment a(c c1, Fragment fragment)
    {
        c1.d = fragment;
        return fragment;
    }

    static String b(c c1)
    {
        return c1.a;
    }

    static Class c(c c1)
    {
        return c1.b;
    }

    static Bundle d(c c1)
    {
        return c1.c;
    }
}
